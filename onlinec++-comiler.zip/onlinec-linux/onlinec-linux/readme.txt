go inside onlinec
open cmd and run "pythton manage.py runserver 0.0.0.0:800"
got to browser url "http://localhost:800/c-run/index"