from django.contrib import admin
from userapp.models import saveddata

admin.site.register(saveddata)
# Register your models here.
